using UnityEditor.SceneManagement;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Player birdBek;
    public GameObject startBtn;
    public int stage = 1;
    public bool isGameStarted = false;
    public bool isPaused = false;
    private float countdownTimer = 8f;
    private float restartTimer = 10f; // Change restart timer to 6 seconds
    private bool restartGameTimerActive = false;

    void Start()
    {
        Time.timeScale = 0f;
        if (startBtn != null)
        {
            startBtn.SetActive(true); // Ensure button is active at the start
        }
    }

    void Update()
    {
        if (birdBek.isDead && !restartGameTimerActive)
        {
            restartGameTimerActive = true; // Start the timer
            restartTimer = 10f; // Set to 6 seconds
        }

        if (restartGameTimerActive)
        {
            restartTimer -= Time.unscaledDeltaTime; // Decrease timer
            if (restartTimer <= 0)
            {
                RestartGame(); // Restart the game
            }
        }

        if (isPaused)
        {
            countdownTimer -= Time.unscaledDeltaTime;
            if (countdownTimer <= 0)
            {
                UnpauseGame();
            }
        }
    }

    public void StartGame()
    {
        isGameStarted = true;

        if (startBtn != null)
        {
            startBtn.SetActive(false); // Hide the start button after pressing
        }
        Time.timeScale = 1f; // Start the game
    }

    public void PauseGame(int nextStage)
    {
        isPaused = true;
        stage = nextStage;
        countdownTimer = 8f;
        Time.timeScale = 0f; // Pause the game
    }

    private void UnpauseGame()
    {
        isPaused = false;
        Time.timeScale = 1f; // Resume the game
    }

    public void RestartGame()
    {
        EditorSceneManager.LoadScene(0); // Reload the scene
    }
}
