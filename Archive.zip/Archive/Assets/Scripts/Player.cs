using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 5.0f;
    private Rigidbody2D rb;
    public bool isDead = false;
    public AudioSource deathAudio; // Reference to AudioSource

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        // Ensure AudioSource is attached and assigned in Unity
        if (deathAudio == null)
        {
            deathAudio = GetComponent<AudioSource>();
        }
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0) && !isDead && Time.timeScale > 0)
        {
            rb.velocity = Vector2.up * speed;
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (!isDead)
        {
            isDead = true;

            // Play death audio when player dies
            if (deathAudio != null)
            {
                deathAudio.Play();
            }
        }
    }
}
