using UnityEngine;

public class ObstaclesSpawner : MonoBehaviour
{
    public GameObject obstacles;
    public float direction;
    public float spawnInterval = 3.0f;
    private float time = 0f;
    public int obstacleCount = 0;
    public GameManager gameManager;

    void Start()
    {
        // Attempt to find the GameManager if it's not assigned in the Inspector
        if (gameManager == null)
        {
            gameManager = FindObjectOfType<GameManager>();
        }

        if (gameManager == null)
        {
            Debug.LogError("GameManager not assigned or found!");
        }
    }

    void Update()
    {
        if (gameManager == null || !gameManager.isGameStarted || gameManager.isPaused) return;

        if (time > spawnInterval)
        {
            GameObject go = Instantiate(obstacles);
            go.transform.position = transform.position + new Vector3(0f, Random.Range(-direction, direction), 0f);

            Obstacles obsScript = go.GetComponent<Obstacles>();
            if (obsScript != null)
            {
                obsScript.currentStage = gameManager.stage;
            }

            obstacleCount++;

            // Transition stages
            if (obstacleCount == 10 && gameManager.stage == 1)
            {
                gameManager.PauseGame(2);
            }
            else if (obstacleCount == 25 && gameManager.stage == 2)
            {
                gameManager.PauseGame(3);
            }

            time = 0f;
            Destroy(go, 10); // Destroy after 10 seconds
        }

        time += Time.deltaTime;
    }
}
