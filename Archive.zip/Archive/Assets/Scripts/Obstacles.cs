using UnityEngine;

public class Obstacles : MonoBehaviour
{
    public float speed = 1.0f;
    public int currentStage = 1;
    private float verticalMovement;
    private float horizontalMovement;

    void FixedUpdate()
    {
        Vector3 movement = Vector3.left * speed * Time.deltaTime;

        if (currentStage >= 2)
        {
            verticalMovement = Mathf.Sin(Time.time * 1.0f) * 0.5f;
            movement += Vector3.up * verticalMovement;
        }

        if (currentStage == 3)
        {
            horizontalMovement = Mathf.Cos(Time.time * 1.0f) * 0.5f;
            movement += Vector3.right * horizontalMovement;
        }

        transform.position += movement;
    }
}
